# verademo-python

Based on the Django 1.11 'Polls' tutorial app

Contains XSS, see if you can find it!

Also contains vulnerable OSS components.
